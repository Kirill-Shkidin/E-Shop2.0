<?
$x = 10;
echo $x;