<?php
class Test{
     function Test(){
        return "Good 1";
    }
}