-- phpMyAdmin SQL Dump
-- version 4.9.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Jun 17, 2020 at 08:46 AM
-- Server version: 5.7.26
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `E-shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `id_good` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `amount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `id_good`, `id_user`, `amount`) VALUES
(138429, 1, 0, 5),
(138430, 5, 0, 2),
(138433, 6, 1, 3),
(138436, 4, 2, 12),
(138437, 2, 2, 2),
(138439, 3, 2, 3);

-- --------------------------------------------------------

--
-- Table structure for table `goods`
--

CREATE TABLE `goods` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `price` float NOT NULL,
  `src` varchar(255) NOT NULL,
  `src_small` varchar(255) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `goods`
--

INSERT INTO `goods` (`id`, `name`, `description`, `price`, `src`, `src_small`, `is_active`) VALUES
(1, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 10, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(2, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 20, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(3, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 30, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(4, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 40, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(5, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 50, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(6, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 60, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(7, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 10, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(8, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 20, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(9, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 30, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(10, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 40, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(11, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 50, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(12, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 60, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(13, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 10, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(14, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 20, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(15, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 30, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(16, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 40, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(17, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 50, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(18, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 60, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(19, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 10, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(20, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 20, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(21, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 30, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(22, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 40, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(23, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 50, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(24, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 60, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(25, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 10, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(26, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 20, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(27, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 30, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(28, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 40, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(29, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 50, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(30, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 60, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(31, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 10, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(32, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 20, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(33, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 30, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(34, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 40, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(35, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 50, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(36, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 60, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(37, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 10, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(38, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 20, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(39, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 30, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(40, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 40, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(41, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 50, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(42, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 60, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(43, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 10, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(44, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 20, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(45, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 30, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(46, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 40, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(47, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 50, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(48, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 60, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(49, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 10, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(50, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 20, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(51, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 30, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(52, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 40, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(53, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 50, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(54, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 60, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(55, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 10, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(56, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 20, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(57, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 30, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(58, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 40, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(59, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 50, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(60, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 60, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(61, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 10, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(62, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 20, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(63, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 30, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(64, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 40, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(65, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 50, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(66, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 60, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(67, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 10, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(68, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 20, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(69, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 30, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(70, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 40, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(71, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 50, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(72, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 60, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(73, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 10, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(74, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 20, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(75, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 30, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(76, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 40, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(77, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 50, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(78, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 60, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(79, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 10, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(80, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 10, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(81, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 20, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(82, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 30, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(83, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 40, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(84, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 50, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(85, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 60, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(86, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 10, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(87, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 20, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(88, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 30, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(89, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 40, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(90, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 50, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(91, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 60, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(92, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 10, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(93, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 20, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(94, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 30, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(95, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 40, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(96, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 50, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(97, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 60, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(98, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 10, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(99, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 20, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(100, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 30, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(101, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 40, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(102, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 50, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(103, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 60, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(104, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 10, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(105, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 20, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(106, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 30, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(107, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 40, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(108, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 50, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(109, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 60, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1),
(110, 'T-Shirt Summer Vibes', 'White Summer Vibes T-shirt in the uiKit line with a colorful print.\r\nMade of jersey cotton. T-shirt fits perfectly with jeans, pants or shorts.', 10, 'img/product-img/AdobeStock_236655481@2x.jpg', 'img/product-img/AdobeStock_236655481.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id_user` int(11) NOT NULL,
  `name` varchar(55) NOT NULL,
  `login` text NOT NULL,
  `password` text NOT NULL,
  `role` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id_user`, `name`, `login`, `password`, `role`) VALUES
(1, '', 'admin', '202cb962ac59075b964b07152d234b70', 1),
(2, '', 'user', '202cb962ac59075b964b07152d234b70', 0),
(3, '', 'admin@mail.ru', '202cb962ac59075b964b07152d234b70', 0),
(4, '', '', '123', 0),
(5, '123', '123', '07b432d25170b469b57095ca269bc202202cb962ac59075b964b07152d234b70', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `id_good` (`id_good`);

--
-- Indexes for table `goods`
--
ALTER TABLE `goods`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=138440;

--
-- AUTO_INCREMENT for table `goods`
--
ALTER TABLE `goods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=111;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
