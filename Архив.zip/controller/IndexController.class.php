<?php

class IndexController extends Controller
{
  public $view = 'index';
  public $title;

  function __construct()
  {
    parent::__construct();
    $this->title .= '';
  }

  //Метод, который отправляет в представление информацию в виде переменной content_data

  function index($selectedValue)
  {
    if (isset($selectedValue['id'])) {
      $params = [':selectedValue' => $selectedValue['id']];
    } else {
      $params = [':selectedValue' => 30];
    }

    $goods = db::getInstance()->Select('SELECT * FROM goods, images 
                                              where goods.id = images.id_good and goods.id < :selectedValue', $params);
    return $goods;
  }

  function addToCart($id_good)
  {
    $obj = new Basket();
    $obj->setIdGood($id_good);
    $obj->save();
    return true;
  }
}

//site/index.php?path=index/test/5