<?php

class GoodController extends Controller
{
  public $view = 'good';
  public $title;

  function __construct()
  {
    parent::__construct();
    $this->title .= '';
  }

  //Метод, который отправляет в представление информацию в виде переменной content_data

  function good($id_good)
  {

    if (isset($id_good['id'])) {
      $params = array(':id' => $id_good['id']);
    } else {
      $params = array(':id' => 1);
    }

    $good = db::getInstance()->Select('SELECT * FROM goods, images 
                                              where goods.id = images.id_good and goods.id = :id', $params);

    return $good;
  }




}

//site/index.php?path=index/test/5