<?php

class UserController extends Controller
{
    function index(){

    }

}