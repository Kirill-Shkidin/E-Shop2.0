'use strict';

var counter = makeCounter();

$(document).ready(renderAllGoods(30));
$(document).ready(counter.reset());

function addToCart(idGood) {
  $.ajax({
    url: 'index.php?path=index/addToCart/' + idGood, // путь к php-обработчику
    type: 'GET', // метод передачи данных
    data: 'asAjax', // данные, которые передаем на сервер
    error: function (req, text, error) { // отслеживание ошибок во время выполнения ajax-запроса
      alert('Хьюстон, У нас проблемы! ' + text + ' | ' + error);
    },
    success: function (obj) {
      console.log(idGood);
      console.log(obj);


    }
  });
};

// function deleteFromCart(idGood) {
//   var str = "delCartId=" + idGood;
//   $.ajax({
//     url: '../controllers/cartController.php', // путь к php-обработчику
//     dataType: 'json', // тип ожидаемых данных в ответе
//     type: 'POST', // метод передачи данных
//     data: str, // данные, которые передаем на сервер
//     error: function (req, text, error) { // отслеживание ошибок во время выполнения ajax-запроса
//       alert('Хьюстон, У нас проблемы! ' + text + ' | ' + error);
//     },
//     success: function (response) {//удаляем вёрстку одного товвара
//       $('#' + response).detach();
//     }
//   });
// };

// function increaseCart(idGood) {
//   let str = "increaseCartId=" + idGood;
//   $.ajax({
//     url: '../controllers/cartController.php', // путь к php-обработчику
//     type: 'POST', // метод передачи данных
//     data: str, // данные, которые передаем на сервер
//     error: function (req, text, error) { // отслеживание ошибок во время выполнения ajax-запроса
//       alert('Хьюстон, У нас проблемы! ' + text + ' | ' + error);
//     },
//     success: function (response) {
//       let obj = jQuery.parseJSON(response);
//       $('#amount' + obj.id).val(obj.amount);
//       $('#price' + obj.id).text('$' + obj.sumPrice);
//     }
//   });
// };
//
// function decreaseCart(idGood) {
//   var str = "decreaseCartId=" + idGood;
//   $.ajax({
//     url: '../controllers/cartController.php', // путь к php-обработчику
//     type: 'POST', // метод передачи данных
//     data: str, // данные, которые передаем на сервер
//     error: function (req, text, error) { // отслеживание ошибок во время выполнения ajax-запроса
//       alert('Хьюстон, У нас проблемы! ' + text + ' | ' + error);
//     },
//     success: function (response) {
//       let obj = jQuery.parseJSON(response);
//       $('#amount' + obj.id).val(obj.amount);
//       $('#price' + obj.id).text('$' + obj.sumPrice);
//     }
//   });
// };

// function decreaseAmount(id) {
//   var str = "decreaseAmount=" + id;
//   $.ajax({
//     url: '../controllers/cartController.php', // путь к php-обработчику
//     type: 'POST', // метод передачи данных
//     data: str, // данные, которые передаем на сервер
//     error: function (req, text, error) { // отслеживание ошибок во время выполнения ajax-запроса
//       alert('Хьюстон, У нас проблемы! ' + text + ' | ' + error);
//     },
//     success: function (response) {
//       $('#amount' + id).val(response);
//     }
//   });
// };
//
// function increaseAmount(id) {
//   var str = "increaseAmount=" + id;
//   $.ajax({
//     url: '../controllers/cartController.php', // путь к php-обработчику
//     type: 'POST', // метод передачи данных
//     data: str, // данные, которые передаем на сервер
//     error: function (req, text, error) { // отслеживание ошибок во время выполнения ajax-запроса
//       alert('Хьюстон, У нас проблемы! ' + text + ' | ' + error);
//     },
//     success: function (response) {
//       $('#amount' + id).val(response);
//     }
//   });
// };

function makeCounter() {
  var currentCount = 1;

  return { // возвратим объект вместо функции
    getNext: function() {
      return currentCount++;
    },

    set: function(value) {
      currentCount = value;
    },

    reset: function() {
      currentCount = 1;
    }
  };
}



function changeAmountOnPage(selectedValue, increment = 0) {
  if (increment != 0) {
    selectedValue = parseInt(selectedValue) + parseInt(increment)*parseInt(counter.getNext());
  }
  $.ajax({
    url: 'index.php?path=index/index/' + selectedValue, // путь к php-обработчику
    type: 'GET', // метод передачи данных
    data: 'asAjax', // данные, которые передаем на сервер
    error: function (req, text, error) { // отслеживание ошибок во время выполнения ajax-запроса
      alert('Хьюстон, У нас проблемы! ' + text + ' | ' + error);
    },
    success: function () {
      console.log(selectedValue);
      renderAllGoods(selectedValue);
    }
  });
}

// $('#amountOnPage').change(function() {
//   alert('The option with value ' + $(this).val() + ' and text ' + $(this).text() + ' was selected.');
// });



function renderAllGoods(selectedValue) {
  $.ajax({
    url: 'index.php?path=index/index/' + selectedValue, // путь к php-обработчику
    type: 'GET', // метод передачи данных
    dataType: 'json', // тип ожидаемых данных в ответе
    data: 'asAjax', // данные, которые передаем на сервер
    error: function (req, text, error) { // отслеживание ошибок во время выполнения ajax-запроса
      alert('Хьюстон, У нас проблемы! ' + text + ' | ' + error);
    },
    success: function (dataAnswer) {
      let goods = '';
      //console.log(dataAnswer);
      //console.log(dataAnswer.content_data);
      let data = dataAnswer.content_data;
      for (let key in data) {
        goods += '<div class="good">' +
          '<div class="img-container"><a href="index.php?path=good/good/' + data[key].id + '">' +
          '<img src="' + data[key].src_1 + '" alt="' + data[key].name + '" title="' + data[key].name +
          '"></a></div>' +
          '<h3 class="good-name"><a href="index.php?path=good/good/' + data[key].id + '">' + data[key].name + '</a></h3>' +
          '<p class="price">$' + data[key].price +
          '</p><p><input type="button" value=\'Add to cart\' onclick="addToCart(' + data[key].id +
          ')" class="add-to-basket"></p></div>'
      }

      $('.productList').html(goods);
    }
  });
}