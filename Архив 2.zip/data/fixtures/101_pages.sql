TRUNCATE TABLE pages;
INSERT INTO pages (`name`) VALUES ('Главная');
INSERT INTO pages (`name`) VALUES ('О Магазине');
INSERT INTO pages (`name`) VALUES ('Каталог');
